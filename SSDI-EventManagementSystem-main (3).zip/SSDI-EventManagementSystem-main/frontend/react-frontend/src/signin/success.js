import React, { Component } from "react";

export default class Success extends Component {
    render() {
        return (
            <div>
                <p>Welcome back!</p>
            </div>
        );
    }
}