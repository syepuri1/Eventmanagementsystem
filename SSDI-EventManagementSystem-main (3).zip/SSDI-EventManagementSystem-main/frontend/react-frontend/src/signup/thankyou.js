import React, { Component } from "react";
import { Link } from "react-router-dom";
import '../App.css';

import { useHistory } from "react-router-dom";

function Thankyou() {
    window.location.href = '/';
}

export default Thankyou;