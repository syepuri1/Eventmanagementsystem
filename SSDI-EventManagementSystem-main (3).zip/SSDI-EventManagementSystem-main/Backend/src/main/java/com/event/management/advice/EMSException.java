package com.event.management.advice;

public class EMSException extends RuntimeException{

	public EMSException() {
		super();
	}
	
	public EMSException(String string) {
		super(string);
	}

	private static final long serialVersionUID = 1L;

}
