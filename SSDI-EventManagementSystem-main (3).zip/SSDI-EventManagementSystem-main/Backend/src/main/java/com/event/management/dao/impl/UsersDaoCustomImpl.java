package com.event.management.dao.impl;

import com.event.management.dao.UsersDaoCustom;

public class UsersDaoCustomImpl implements UsersDaoCustom {

}
