package com.event.management.service;

public interface CommentService {

}
