package com.event.management.dao;

public interface CommentDao {

}
