package com.event.management.dao;

public interface UsersDaoCustom {

}
