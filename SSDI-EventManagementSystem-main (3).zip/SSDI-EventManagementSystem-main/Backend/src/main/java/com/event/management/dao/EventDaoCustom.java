package com.event.management.dao;

import java.util.List;

import com.event.management.model.Event;

public interface EventDaoCustom {

	List<Event> getEvents();

}
