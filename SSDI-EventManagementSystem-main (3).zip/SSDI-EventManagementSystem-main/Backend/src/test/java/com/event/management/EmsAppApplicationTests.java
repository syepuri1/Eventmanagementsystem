package com.event.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsAppApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("hello");
	}

}
