# SSDI-EventManagementSystem
Event Management System
